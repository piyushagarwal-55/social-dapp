// src/identity-kit-example-frontend/tailwind.config.js
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",  // include everything inside /src
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
